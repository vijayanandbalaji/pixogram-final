import { User } from './user.model';

export class Follow{
    id:number;
    userId:User;
    followId:User;
}